"""Orchestrator — runs the 3-step oncall pipeline.

Supports two modes:
  1. Structured: signal_name, repo, channel (from TUI/direct)
  2. Intent-driven: raw query → LLM-extracted intent → selective pipeline
"""

from oncall_agent.mcp_clients.client import MCPClient
from oncall_agent.memory.store import OncallMemory
from oncall_agent.config import config
from oncall_agent.steps.step1_triage import step_triage
from oncall_agent.steps.step2_wow import step_wow_compare
from oncall_agent.steps.step3_reason import step_reason_and_act


class OncallOrchestrator:
    """Orchestrates the 3-step oncall analysis pipeline."""

    def __init__(self):
        self.adx_client = MCPClient("adx-kusto", config.adx_mcp.url)
        self.github_client = MCPClient("github", config.github_mcp.url)
        self.teams_client = MCPClient("teams", config.teams_mcp.url)
        self.memory = OncallMemory(config.memory_path)

    async def run(
        self,
        signal_name: str,
        repo: str = "",
        teams_channel: str = "",
        model: str = None,
        intent: dict = None,
        raw_query: str = "",
    ) -> dict:
        """Execute the pipeline.
        
        When intent is provided (from HTTP trigger), uses it to decide which
        steps to run and injects the raw query as additional context.
        """
        result = {"signal_name": signal_name, "steps": {}}
        intent = intent or {}

        # Inject raw query and intent into pipeline context
        extra_context = ""
        if raw_query:
            extra_context += f"\n\n## Original Incident Metadata\n{raw_query}"
        if intent.get("key_entities"):
            extra_context += f"\n\n## Key Entities\n{', '.join(intent['key_entities'])}"
        if intent.get("kusto_hints"):
            extra_context += f"\n\n## Kusto Hints\n{', '.join(intent['kusto_hints'])}"

        # Step 1: Triage — Global or Windows first?
        if intent.get("should_run_triage", True):
            print(f"[Step 1] Triage: {signal_name}")
            triage = await step_triage(self.adx_client, signal_name)
            result["steps"]["triage"] = triage
            print(f"  → Verdict: {triage['verdict']}")
        else:
            result["steps"]["triage"] = {"verdict": "Skipped", "details": {}, "signal_name": signal_name}

        # Step 2: Week-over-Week comparison
        if intent.get("should_run_wow", True):
            print(f"[Step 2] WoW comparison")
            wow = await step_wow_compare(self.adx_client, self.github_client, signal_name, repo)
            result["steps"]["wow"] = wow
            print(f"  → Trend: {wow['trend']} ({wow['change_percent']}%)")
        else:
            result["steps"]["wow"] = {
                "current_count": 0, "previous_count": 0, "delta": 0,
                "change_percent": 0, "trend": "skipped", "recent_changes": [],
            }

        # Step 3: Reasoning + Summary + Teams
        print(f"[Step 3] Reasoning & action")
        should_notify = intent.get("should_notify", bool(teams_channel))
        analysis = await step_reason_and_act(
            self.teams_client,
            self.memory,
            result["steps"]["triage"],
            result["steps"]["wow"],
            teams_channel if should_notify else "",
            model=model,
            extra_context=extra_context,
        )
        result["steps"]["analysis"] = analysis
        print(f"  → Severity: {analysis['severity']}")
        print(f"  → Teams sent: {analysis['teams_sent']}")

        # Overall
        result["severity"] = analysis["severity"]
        result["summary"] = analysis["summary"]
        result["actions"] = analysis["actions"]

        return result
