"""Memory mechanism — persistent cross-session oncall context.

Stores:
- Past incidents (issue, root cause, resolution)
- Known patterns (recurring alerts, flaky services)
- Runbooks and heuristics learned over time
"""

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class OncallMemory:
    """Simple JSON-backed memory with semantic sections."""

    def __init__(self, path: str = "./memory/oncall_memory.json"):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.data: dict[str, list[dict[str, Any]]] = {
            "incidents": [],       # past incident records
            "patterns": [],        # recurring patterns / known issues
            "runbooks": [],        # learned resolution steps
            "wow_comparisons": [], # week-over-week history
        }
        self._load()

    def _load(self):
        if self.path.exists():
            with open(self.path) as f:
                self.data = json.load(f)

    def _save(self):
        with open(self.path, "w") as f:
            json.dump(self.data, f, indent=2, default=str)

    def add(self, section: str, entry: dict[str, Any]):
        entry.setdefault("timestamp", datetime.now(timezone.utc).isoformat())
        self.data.setdefault(section, []).append(entry)
        self._save()

    def search(self, section: str, keyword: str) -> list[dict]:
        """Simple keyword search within a section."""
        results = []
        for entry in self.data.get(section, []):
            text = json.dumps(entry, default=str).lower()
            if keyword.lower() in text:
                results.append(entry)
        return results

    def get_recent(self, section: str, n: int = 10) -> list[dict]:
        return self.data.get(section, [])[-n:]

    def record(self, signal_name: str, result: dict):
        """Record a completed oncall analysis to incidents."""
        self.add("incidents", {
            "signal": signal_name,
            "title": signal_name,
            "severity": result.get("severity", "unknown"),
            "summary": result.get("summary", "")[:500],
            "mode": result.get("mode", "mcp"),
        })

    def get_context_for_llm(self, limit: int = 5) -> str:
        """Build a concise memory context string for LLM reasoning."""
        parts = []
        recent_incidents = self.get_recent("incidents", limit)
        if recent_incidents:
            parts.append("## Recent Incidents")
            for inc in recent_incidents:
                parts.append(f"- [{inc.get('timestamp','')}] {inc.get('title','')}: {inc.get('summary','')}")

        recent_patterns = self.get_recent("patterns", limit)
        if recent_patterns:
            parts.append("\n## Known Patterns")
            for p in recent_patterns:
                parts.append(f"- {p.get('pattern','')}")

        recent_wow = self.get_recent("wow_comparisons", 3)
        if recent_wow:
            parts.append("\n## Recent WoW Comparisons")
            for w in recent_wow:
                parts.append(f"- [{w.get('timestamp','')}] {w.get('summary','')}")

        return "\n".join(parts) if parts else "(No prior oncall memory)"
